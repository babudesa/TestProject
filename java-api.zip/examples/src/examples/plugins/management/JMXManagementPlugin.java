package examples.plugins.management;

import com.guidewire.pl.plugin.management.ManagementPlugin;

public class JMXManagementPlugin extends JMXManagementPluginBase implements ManagementPlugin {
}
