package examples.plugins.authenticationservice;

import com.guidewire.pl.plugin.security.AuthenticationServicePlugin;

public class CCAuthenticationServicePlugin extends CCAuthenticationServicePluginBase implements AuthenticationServicePlugin{
}
