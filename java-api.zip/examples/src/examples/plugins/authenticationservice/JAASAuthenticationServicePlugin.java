package examples.plugins.authenticationservice;

import com.guidewire.pl.plugin.security.AuthenticationServicePlugin;

/**
 * Sample authentication service to be used with WebSEAL.
 */
public class JAASAuthenticationServicePlugin  extends JAASAuthenticationServicePluginBase implements AuthenticationServicePlugin{
}
